# MA_Wednesday3pm_Team3

FIT2101 S2 2026 group repository.

## Team

Add your team members and roles here.

## Getting Started

1. Clone this repository.
2. Create a branch for your work.
3. Commit regularly with clear messages.
4. Open a merge request when your work is ready for review.

## Repository Structure

Update this section as your project grows.

## Notes

Keep your project work, documentation, setup instructions, and relevant artefacts in this repository.
Do not share this repository outside your group and the teaching team.
